<?php require APPROOT . '/views/layout/header.php'; ?>

<div class="container-fluid mt-4 px-4">
    <div class="row">
        <div class="col-md-12">
            <?php flash('complaint_success'); ?>
            <?php flash('complaint_error'); ?>
            <?php flash('auth_error'); ?>
            
            <div class="row mb-4">
                <div class="col">
                    <div class="card bg-primary text-white h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="me-3">
                                    <div class="text-white-75 small">Pending Approval</div>
                                    <div class="text-lg fw-bold" style="font-size: 2rem;"><?php echo $data['stats']['pending']; ?></div>
                                </div>
                                <i class="fas fa-inbox fa-2x text-white-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card bg-success text-white h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="me-3">
                                    <div class="text-white-75 small">Approved by You</div>
                                    <div class="text-lg fw-bold" style="font-size: 2rem;"><?php echo $data['stats']['approved']; ?></div>
                                </div>
                                <i class="fas fa-check-double fa-2x text-white-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card bg-danger text-white h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="me-3">
                                    <div class="text-white-75 small">Rejected by You</div>
                                    <div class="text-lg fw-bold" style="font-size: 2rem;"><?php echo $data['stats']['rejected']; ?></div>
                                </div>
                                <i class="fas fa-times-circle fa-2x text-white-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <ul class="nav nav-tabs mb-4" id="aoDashboardTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active fw-bold text-primary" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab"><i class="fas fa-list-alt me-1"></i> Pending Review</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold text-success" id="submitted-tab" data-bs-toggle="tab" data-bs-target="#submitted" type="button" role="tab"><i class="fas fa-check-double me-1"></i> Submitted to GS</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold text-danger" id="rejected-tab" data-bs-toggle="tab" data-bs-target="#rejected" type="button" role="tab"><i class="fas fa-times-circle me-1"></i> Rejected Reports</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold text-info" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab"><i class="fas fa-list me-1"></i> All Complaints</button>
                </li>
            </ul>

            <div class="tab-content" id="aoDashboardTabsContent">
                <!-- Pending Tab -->
                <div class="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="pending-tab">
                    <div class="card shadow border-0 mb-4 rounded-4">
                        <div class="card-header bg-gradient bg-primary text-white py-3 d-flex justify-content-between align-items-center rounded-top-4">
                            <h5 class="mb-0 fw-bold">Pending Complaints (Administrative Officer)</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($data['complaints'])): ?>
                                <div class="text-center py-5 text-muted">
                                    <i class="fas fa-check-circle fa-4x mb-3 text-success opacity-50"></i>
                                    <h4>All Caught Up!</h4>
                                    <p>There are no complaints pending your review at the moment.</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive p-2">
                                    <table class="table table-hover align-middle border-bottom">
                                        <thead class="table-light text-uppercase text-secondary" style="font-size: 0.85rem;">
                                            <tr>
                                                <th class="ps-3">Complaint No</th>
                                                <th>Date</th>
                                                <th>Subject</th>
                                                <th>Category</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($data['complaints'] as $complaint): ?>
                                                <tr style="transition: all 0.2s ease;">
                                                    <td class="ps-3"><span class="text-primary fw-bold"><?php echo htmlspecialchars($complaint->complaint_no); ?></span></td>
                                                    <td><?php echo htmlspecialchars($complaint->date); ?></td>
                                                    <td><?php echo htmlspecialchars($complaint->subject); ?></td>
                                                    <td><span class="badge bg-info bg-opacity-10 text-info border border-info rounded-pill px-3 py-2"><i class="fas fa-tag me-1"></i> <?php echo htmlspecialchars($complaint->category_name); ?></span></td>
                                                    <td>
                                                        <span class="badge bg-warning bg-opacity-10 text-warning border border-warning rounded-pill px-3 py-2"><i class="fas fa-hourglass-half me-1"></i> <?php echo htmlspecialchars($complaint->status); ?></span>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo URLROOT; ?>/ao/show/<?php echo $complaint->id; ?>" class="btn btn-sm btn-primary rounded-pill px-3 shadow-sm">
                                                            <i class="fas fa-search me-1"></i> Review
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Submitted Tab -->
                <div class="tab-pane fade" id="submitted" role="tabpanel" aria-labelledby="submitted-tab">
                    <div class="card shadow border-0 mb-4 rounded-4">
                        <div class="card-header bg-gradient bg-success text-white py-3 d-flex justify-content-between align-items-center rounded-top-4">
                            <h5 class="mb-0 fw-bold">Submitted to GS</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($data['submitted_to_gs'])): ?>
                                <div class="text-center py-5 text-muted">
                                    <i class="fas fa-folder-open fa-4x mb-3 text-secondary opacity-50"></i>
                                    <h4>No Reports</h4>
                                    <p>You haven't submitted any complaints to the GS yet.</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive p-2">
                                    <table class="table table-hover align-middle border-bottom">
                                        <thead class="table-light text-uppercase text-secondary" style="font-size: 0.85rem;">
                                            <tr>
                                                <th class="ps-3">Complaint No</th>
                                                <th>Date</th>
                                                <th>Subject</th>
                                                <th>Category</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($data['submitted_to_gs'] as $complaint): ?>
                                                <tr style="transition: all 0.2s ease;">
                                                    <td class="ps-3"><span class="text-success fw-bold"><?php echo htmlspecialchars($complaint->complaint_no); ?></span></td>
                                                    <td><?php echo htmlspecialchars($complaint->date); ?></td>
                                                    <td><?php echo htmlspecialchars($complaint->subject); ?></td>
                                                    <td><span class="badge bg-info bg-opacity-10 text-info border border-info rounded-pill px-3 py-2"><i class="fas fa-tag me-1"></i> <?php echo htmlspecialchars($complaint->category_name); ?></span></td>
                                                    <td><span class="badge bg-success bg-opacity-10 text-success border border-success rounded-pill px-3 py-2"><i class="fas fa-check me-1"></i> <?php echo htmlspecialchars($complaint->status); ?></span></td>
                                                    <td>
                                                        <a href="<?php echo URLROOT; ?>/ao/show/<?php echo $complaint->id; ?>" class="btn btn-sm btn-outline-success rounded-pill px-3 shadow-sm">
                                                            <i class="fas fa-eye me-1"></i> View
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Rejected Tab -->
                <div class="tab-pane fade" id="rejected" role="tabpanel" aria-labelledby="rejected-tab">
                    <div class="card shadow border-0 mb-4 rounded-4">
                        <div class="card-header bg-gradient bg-danger text-white py-3 d-flex justify-content-between align-items-center rounded-top-4">
                            <h5 class="mb-0 fw-bold">Rejected Reports</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($data['rejected_reports'])): ?>
                                <div class="text-center py-5 text-muted">
                                    <i class="fas fa-check-circle fa-4x mb-3 text-success opacity-50"></i>
                                    <h4>Good Job!</h4>
                                    <p>You have no rejected reports.</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive p-2">
                                    <table class="table table-hover align-middle border-bottom">
                                        <thead class="table-light text-uppercase text-secondary" style="font-size: 0.85rem;">
                                            <tr>
                                                <th class="ps-3">Complaint No</th>
                                                <th>Date</th>
                                                <th>Subject</th>
                                                <th>Category</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($data['rejected_reports'] as $complaint): ?>
                                                <tr style="transition: all 0.2s ease;">
                                                    <td class="ps-3"><span class="text-danger fw-bold"><?php echo htmlspecialchars($complaint->complaint_no); ?></span></td>
                                                    <td><?php echo htmlspecialchars($complaint->date); ?></td>
                                                    <td><?php echo htmlspecialchars($complaint->subject); ?></td>
                                                    <td><span class="badge bg-info bg-opacity-10 text-info border border-info rounded-pill px-3 py-2"><i class="fas fa-tag me-1"></i> <?php echo htmlspecialchars($complaint->category_name); ?></span></td>
                                                    <td><span class="badge bg-danger bg-opacity-10 text-danger border border-danger rounded-pill px-3 py-2"><i class="fas fa-times me-1"></i> <?php echo htmlspecialchars($complaint->status); ?></span></td>
                                                    <td>
                                                        <a href="<?php echo URLROOT; ?>/ao/show/<?php echo $complaint->id; ?>" class="btn btn-sm btn-outline-danger rounded-pill px-3 shadow-sm">
                                                            <i class="fas fa-eye me-1"></i> View
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- All Tab -->
                <div class="tab-pane fade" id="all" role="tabpanel" aria-labelledby="all-tab">
                    <div class="card shadow border-0 mb-4 rounded-4">
                        <div class="card-header bg-gradient bg-info text-white py-3 d-flex justify-content-between align-items-center rounded-top-4">
                            <h5 class="mb-0 fw-bold">All System Complaints</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($data['all_complaints'])): ?>
                                <div class="text-center py-5 text-muted">
                                    <i class="fas fa-folder-open fa-4x mb-3 text-secondary opacity-50"></i>
                                    <h4>No Complaints Found</h4>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive p-2">
                                    <table class="table table-hover align-middle border-bottom">
                                        <thead class="table-light text-uppercase text-secondary" style="font-size: 0.85rem;">
                                            <tr>
                                                <th class="ps-3">Complaint No</th>
                                                <th>Date</th>
                                                <th>Applicant</th>
                                                <th>Subject</th>
                                                <th>Category</th>
                                                <th>Current Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($data['all_complaints'] as $complaint): ?>
                                                <tr style="transition: all 0.2s ease;">
                                                    <td class="ps-3"><span class="text-info fw-bold"><?php echo htmlspecialchars($complaint->complaint_no); ?></span></td>
                                                    <td><?php echo htmlspecialchars($complaint->date); ?></td>
                                                    <td><?php echo htmlspecialchars($complaint->applicant_name); ?></td>
                                                    <td><?php echo htmlspecialchars($complaint->subject); ?></td>
                                                    <td><span class="badge bg-info bg-opacity-10 text-info border border-info rounded-pill px-3 py-1"><?php echo htmlspecialchars($complaint->category_name); ?></span></td>
                                                    <td><span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary rounded-pill px-3 py-1"><?php echo htmlspecialchars($complaint->status); ?></span></td>
                                                    <td>
                                                        <a href="<?php echo URLROOT; ?>/complaints/show/<?php echo $complaint->id; ?>" class="btn btn-sm btn-outline-info rounded-pill px-3 shadow-sm">
                                                            <i class="fas fa-eye me-1"></i> View
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require APPROOT . '/views/layout/footer.php'; ?>
